def transcribe_dna_sequence(dna_sequence):

    return dna_sequence.replace("T", "U")
