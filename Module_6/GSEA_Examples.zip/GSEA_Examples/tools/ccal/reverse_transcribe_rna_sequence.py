def reverse_transcribe_rna_sequence(rna_sequence):

    return rna_sequence.replace("U", "T")
