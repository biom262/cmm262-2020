def untitle_str(str_):

    return str_.lower().replace(" ", "_").replace("-", "_")
