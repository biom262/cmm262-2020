from os.path import dirname

DATA_DIRECTORY_PATH = "{}/../data".format(dirname(__file__))
