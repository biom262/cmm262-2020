from numpy import finfo

ALMOST_ZERO = finfo(float).resolution
